﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace otopark_final_ödevi
{
    public partial class OdemeDgv : Form
    {
        public OdemeDgv()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ferha\OneDrive\Belgeler\otoparkdtb.mdf;Integrated Security=True;Connect Timeout=30");
        private void button1_Click(object sender, EventArgs e)
        {
            if (AracSahibiTb.Text == "" || TelefonTb.Text == "" || TarihDtp.Text == "" || PlakaTb.Text == "" || GirisTb.Text == "")
            {
                MessageBox.Show("Eksik Bilgi");
            }
            else
            {
                try
                {
                    baglanti.Open();
                    string query = "insert into ArabaKayitTbl values('" + AracSahibiTb.Text + "','" + TelefonTb.Text + "','" + TarihDtp.Text + "','" + PlakaTb.Text + "','" + GirisTb.Text + "')";
                    SqlCommand komut = new SqlCommand(query, baglanti);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Araç Kaydı Başarıyla Eklenmiştir");
                    baglanti.Close();
                    uyeler();
                    fill();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }
        }

        private void uyeler()
        {
            baglanti.Open();
            string query = "select * from ArabaKayitTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, baglanti);
            var ds = new DataSet();
            sda.Fill(ds);
            KayitDgv.DataSource = ds.Tables[0];
            baglanti.Close();
        }
        private void odemeler()
        {
            baglanti.Open();
            string query = "select * from OdemeTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, baglanti);
            var ds = new DataSet();
            sda.Fill(ds);
            OdemeeDgv.DataSource = ds.Tables[0];
            baglanti.Close();
        }
        private void temizle()
        {
            AracSahibiCb.Text = "";
            PlakaCb.Text = "";
            TutarTb.Text = "";
            CikisTb.Text = "";
        }

        private void fill()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select AracSahibi,Plaka from ArabaKayitTbl", baglanti);
            SqlDataReader rdr;
            rdr = komut.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("AracSahibi,Plaka", typeof(string));
            dt.Load(rdr);
            AracSahibiCb.ValueMember = "AracSahibi";
            PlakaCb.ValueMember = "Plaka";
            AracSahibiCb.DataSource = dt;
            PlakaCb.DataSource = dt;
            baglanti.Close();



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uyeler();
            fill();
            odemeler();

        }
        int AracKey;
        private void button2_Click(object sender, EventArgs e)
        {
            if (AracSahibiTb.Text == "" || TelefonTb.Text == "" || TarihDtp.Text == "" || PlakaTb.Text == "" || GirisTb.Text == "")
            {
                MessageBox.Show("Silinecek Kaydı Seçiniz");
            }
            else
            {
                AracKey = Convert.ToInt32(KayitDgv.SelectedRows[0].Cells[0].Value.ToString());
                try
                {
                    baglanti.Open();
                    string query = "delete from ArabaKayitTbl where AKayitId=" + AracKey + "";
                    SqlCommand komut = new SqlCommand(query, baglanti);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Araç Kaydı Başarıyla Silinmiştir");
                    baglanti.Close();
                    uyeler();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }
        }

        private void KayitDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void KayitDgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            AracKey = Convert.ToInt32(KayitDgv.SelectedRows[0].Cells[0].Value.ToString());
            AracSahibiTb.Text = KayitDgv.SelectedRows[0].Cells[1].Value.ToString();
            TelefonTb.Text = KayitDgv.SelectedRows[0].Cells[2].Value.ToString();
            TarihDtp.Text = KayitDgv.SelectedRows[0].Cells[3].Value.ToString();
            PlakaTb.Text = KayitDgv.SelectedRows[0].Cells[4].Value.ToString();
            GirisTb.Text = KayitDgv.SelectedRows[0].Cells[5].Value.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (AracSahibiTb.Text == "" || TelefonTb.Text == "" || TarihDtp.Text == "" || PlakaTb.Text == "" || GirisTb.Text == "")
            {
                MessageBox.Show("Eksik Bilgi");
            }
            else
            {
                try
                {
                    baglanti.Open();
                    string query = "UPDATE ArabaKayitTbl SET AracSahibi = @AracSahibi, Telefon = @Telefon, Tarih = @Tarih, Plaka = @Plaka, Giris = @Giris WHERE AKayitId = @AKayitId";

                    SqlCommand komut = new SqlCommand(query, baglanti);
                    komut.Parameters.AddWithValue("@AracSahibi", AracSahibiTb.Text);
                    komut.Parameters.AddWithValue("@Telefon", TelefonTb.Text);
                    komut.Parameters.AddWithValue("@Tarih", TarihDtp.Text);
                    komut.Parameters.AddWithValue("@Plaka", PlakaTb.Text);
                    komut.Parameters.AddWithValue("@Giris", GirisTb.Text);
                    komut.Parameters.AddWithValue("@AKayitId", AracKey);

                    int rowsAffected = komut.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Araç Kaydı Başarıyla Güncellenmiştir");
                    }
                    else
                    {
                        MessageBox.Show("Güncellenen kayıt bulunamadı.");
                    }

                    baglanti.Close();
                    uyeler();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message);
                }
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            AracSahibiTb.Text = "";
            TelefonTb.Text = "";
            TarihDtp.Text = "";
            PlakaTb.Text = "";
            GirisTb.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        double x, y, z;

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (AracSahibiTb.Text == "" || PlakaTb.Text == "" || TutarTb.Text == "")
            {
                MessageBox.Show("Eksik Bilgi");
            }
            else
            {
                try
                {
                    baglanti.Open();
                    string query = "insert into OdemeTbl values('" + AracSahibiCb.Text + "','" + PlakaCb.Text + "','" + TutarTb.Text + "')";
                    SqlCommand komut = new SqlCommand(query, baglanti);
                    komut.ExecuteNonQuery();
                    MessageBox.Show("Ödeme İşlemi Tamamlanmıştır");
                    baglanti.Close();
                    odemeler();


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DateTime girisZamani;
            DateTime cikisZamani;

            
            if (!IsValidTimeFormat(GirisTb.Text) || !IsValidTimeFormat(CikisTb.Text))
            {
                MessageBox.Show("Girilen saat formatı hatalı. Lütfen HH:mm formatında saat girin.");
                return; 
            }

            
            bool girisValid = DateTime.TryParseExact(GirisTb.Text, "HH:mm", null, System.Globalization.DateTimeStyles.None, out girisZamani);
            bool cikisValid = DateTime.TryParseExact(CikisTb.Text, "HH:mm", null, System.Globalization.DateTimeStyles.None, out cikisZamani);

            if (!girisValid || !cikisValid)
            {
                MessageBox.Show("Girilen saat formatı hatalı. Lütfen HH:mm formatında saat girin.");
                return;
            }

            
            TimeSpan fark = cikisZamani - girisZamani;
            double parkSuresi = fark.TotalHours;

            
            if (parkSuresi <= 1)
            {
                TutarTb.Text = "10";
            }
            else if (parkSuresi > 1 && parkSuresi <= 3)
            {
                TutarTb.Text = "20";
            }
            else if (parkSuresi > 3 && parkSuresi <= 5)
            {
                TutarTb.Text = "35";
            }
            else
            {
                TutarTb.Text = "100";
            }
        }

        
        private bool IsValidTimeFormat(string time)
        {
            string timePattern = @"^([01]?[0-9]|2[0-3]):([0-5]?[0-9])$";  
            return Regex.IsMatch(time, timePattern);
        }
    }
}
       
         
    

